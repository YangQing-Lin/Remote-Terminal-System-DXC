package com.group1.group1_backend.sys.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author linqingchuan
 * @since 2023-03-29
 */
@Controller
@RequestMapping("/sys/userRole")
public class UserRoleController {

}
