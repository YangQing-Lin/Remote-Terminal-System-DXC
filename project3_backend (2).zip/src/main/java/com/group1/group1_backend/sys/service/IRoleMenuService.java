package com.group1.group1_backend.sys.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.group1.group1_backend.sys.entity.RoleMenu;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author laocai
 * @since 2023-02-07
 */
public interface IRoleMenuService extends IService<RoleMenu> {

}
