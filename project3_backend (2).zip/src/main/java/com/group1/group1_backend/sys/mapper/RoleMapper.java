package com.group1.group1_backend.sys.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.group1.group1_backend.sys.entity.Role;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author linqingchuan
 * @since 2023-03-29
 */
public interface RoleMapper extends BaseMapper<Role> {

}
